$(document).ready(function() {
    console.log("Entro a la función document ready");

    var queryString = window.location.search.split('folio=');
    if(queryString != null && queryString.length > 1){
        //$('#buscaFolio').val(queryString[1]);

        setTimeout(function(){
            $('#btn-buscar').click()
        }, 2000);

    }
});

var app = window.angular.module('revalidaciones', ['ngResource']);

app.controller('revalidacionesController', ['$scope', '$http', '$window', '$rootScope',
    function ($scope, $http, $window, $rootScope) {
        $scope.datos = null;
        
        var queryString = $window.location.search.split('folio=');
        if(queryString != null && queryString.length > 1){
            $scope.folio = queryString[1]
        }
        
        $scope.getConsultaByFOLIO = function () {
            var folio;
            $scope.fechaEmision = "";

            $('#sectionResultWithData').hide();
            $('#sectionResultWithoutData').hide();
            $('#sectionErrorWhileConnecting').hide();

            if($scope.folio != null && $scope.folio.length > 1){
                folio = $scope.folio.toUpperCase();

                processing();
                
                $http({
                    method: 'GET',
                    url: global_uri+'/certificado/consultaRevalidaciones/?folio='+folio,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    }
                }).success(function (data) {
                    if(data.datos === undefined || data.datos.length== 0){
                        $scope.datos = 0;
                        $('#sectionResultWithoutData').show();
                        $('html, body').animate({scrollTop: $("#sectionResultWithData").offset().top - 50}, 1000);
                    }else{
                        $scope.datos = data.datos[0];
                        $('#sectionResultWithData').show();
                        $('html, body').animate({scrollTop: $("#sectionResultWithData").offset().top - 50}, 1000);
                    }

                    var fecha = new Date(data.datos[0].fecEmision);
                    const opciones = { year: 'numeric', month: '2-digit', day: '2-digit' };
                    $scope.fechaEmision = fecha.toLocaleDateString('es-mx', opciones);

                    noprocessing();

                }).error(function (error) {
                    $('#sectionErrorWhileConnecting').show();
                    $('html, body').animate({scrollTop: $("#sectionErrorWhileConnecting").offset().top - 50}, 1000);
                    $scope.datos = null;
                });

            }

            console.log("$scope.datos"+$scope.datos);
        };

        $scope.newSearch = function () {
            $scope.datos = null;
            $scope.fechaEmision = "";
            $('#sectionResultWithData').hide();
            $('#sectionResultWithoutData').hide();
            $('#sectionErrorWhileConnecting').hide();
            $scope.resetForm();
        };

        $scope.resetForm = function () {
            $scope.folio = null;
        };

        var processing = function () {
            $("#modal-loading").modal('show');
            $('.tiempo_fuera').hide();
            setTimeout(revisaModal, 5000);
        };

        var noprocessing = function () {
            $("#modal-loading").modal('hide');
        };

        var revisaModal = function () {
            if($("#modal-loading").is(":visible")){
                $('.tiempo_fuera').show();
            }
        };


    }]
);
